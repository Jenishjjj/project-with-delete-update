const mongoose = require('mongoose');

const AdminSchema = mongoose.Schema({
    title : {
        type : String,
        require : true
    },
    isbn : {
        type : String,
        require : true
    },
    author : {
        type : String,
        require : true
    },
    publisher :{
        type : String,
        require : true
    },
    quantity :{
        type : String,
        require : true
    },
    total_page :{
        type : String,
        require : true
    },
    book_type : {
        type : Array,
        require : true
    },
    rating : {
        type : String,
        require : true
    },
    published_date : {
        type : String,
        require : true
    }
})

const Admin = mongoose.model('Admin',AdminSchema);

module.exports = Admin;