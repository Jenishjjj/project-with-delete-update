const express = require('express');

const port = 8009;

const app = express();

const path = require('path');

const db = require('./confige/mongoose');

const Admin = require('./model/Admin');

app.use(express.urlencoded());

app.set('view engine','ejs');
app.set("views",path.join(__dirname,'views'));

app.get('/',(req,res)=>{
    return res.render('home');
})

app.post('/bookDetail',function(req,res){
    Admin.create(req.body)
    .then(function(data){
        return res.redirect('/');
    })
    .catch(function(err){
        console.log(err);
    })
})

app.get('/viewData',function(req,res){
    Admin.find({})
    .then(function(response){
        return res.render('viewdata',{
            'bookData' : response
        })
    })
    .catch(function(err){
        if(err){
            console.log(err);
        }
    })
})

app.get('/deleteRec/:id',(req,res)=>{
    Admin.findByIdAndDelete(req.params.id)
    .then(function(record){
        return res.redirect('/viewdata');
    })
    .catch((err)=>{
        console.log(err);
    })
})

app.get('/updateRec',function(req,res){
    Admin.findById(req.query.id)
    .then(function(record){
        return res.render('update_view',{
            'singleAdmin' : record
        })
    })
    .catch((err)=>{
        console.log(err);
    })
})

app.post('/EditRec',(req,res)=>{
    var AdminId = req.body.EditId;
    Admin.findByIdAndUpdate(AdminId,req.body)
    .then((record)=>{
        return res.redirect('/viewData');
    })
    .catch((err)=>{
        console.log(err);
    })
})


app.listen(port,(err)=>{
    if(err){
        console.log(err);
        return false;
    }
    console.log("Server is running properly");
})